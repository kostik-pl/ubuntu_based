#!/bin/bash

if [[ "$(id -u)" != "0" ]]; then echo "This script must be run as root"; exit 1; fi
ARCH=$(uname -m); if [[ $ARCH != "i686" ]] && [[ $ARCH != "x86_64" ]]; then >&2 echo "Данная архитектура не поддерживается"; exit 1; fi
PM=$(apt-get --version 1>/dev/null 2>&1 && echo apt-get) || PM=$(dnf --version 1>/dev/null 2>&1 && echo dnf) || PM=$(yum --version 1>/dev/null 2>&1 && echo yum)
if [[ $? -ne 0 ]]; then >&2 echo "Данный менеджер пакетов не поддерживается"; exit 1; fi
SDIR=$(dirname $(readlink -f $0))
case $PM in
  apt-get) $PM update && $PM install dkms g++ libjansson-dev -y && { dpkg -s linux-headers-$(uname -r) 1>/dev/null 2>&1 || $PM install linux-headers-$(uname -r) -y; };;
  dnf|yum) $PM clean all && $PM makecache && ($PM install epel-release -y; $PM install jansson-devel -y || $PM --enablerepo=crb install jansson-devel -y && $PM install "kernel-devel-uname-r = $(uname -r)" dkms gcc-c++ -y);;
esac
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при установке пакетов"; exit 1; fi
cp -fpr $SDIR/src/usb-vhci-hcd-1.15.1 /usr/src/
cp -f /usr/src/usb-vhci-hcd-1.15.1/usb-vhci.h /usr/include/linux/
dkms add -m usb-vhci-hcd -v 1.15.1
dkms build -m usb-vhci-hcd -v 1.15.1
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при компиляции исходников 'usb-vhci-hcd'"; exit 1; fi
dkms install -m usb-vhci-hcd -v 1.15.1
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при компиляции исходников 'usb-vhci-hcd'"; exit 1; fi
cd $SDIR/src/libusb_vhci-0.8/
./configure CXXFLAGS='-std=c++11' && make && make install
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при компиляции исходников 'libusb-vhci'"; exit 1; fi
cat /etc/ld.so.conf.d/* | grep -E ^[[:space:]]*/usr/local/lib/?[[:space:]]*$ 1>/dev/null || cat << EOF > /etc/ld.so.conf.d/libc.conf
# libc default configuration
/usr/local/lib
EOF
ldconfig
cd $SDIR/src/UsbHasp/
make CFLAGS=-std=gnu99
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при компиляции исходников 'usbhasp'"; exit 1; fi
cp -fp $SDIR/src/UsbHasp/dist/Release/GNU-Linux/usbhasp /usr/bin/
mkdir -p /etc/usbhaspd/keys/
cat << EOF > /etc/usbhaspd/usbhaspd.conf
# Usbhaspd conf

# Dir for keys. Default /etc/usbhaspd/keys 
# Simply put keys *.json to KEY_DIR
# KEY_DIR=/etc/usbhaspd/keys

EOF
cat << EOF > /usr/bin/usbhaspd
#!/bin/bash

NAME=usbhaspd

DAEMON_BIN=/usr/bin/usbhasp
KEY_DIR=/etc/\${NAME}/keys
DAEMON_CONF=/etc/\${NAME}/\${NAME}.conf

# read optional conf
if test -f \${DAEMON_CONF} ; then . \${DAEMON_CONF}; fi

# Read key list
keys=""
if test -d \${KEY_DIR}; then keys="\${KEY_DIR}/*.json"; fi

DAEMON_ARGS="\$keys"

# Start kernel modules
modprobe usb_vhci_hcd
modprobe usb_vhci_iocifc

# Start daemon
\$DAEMON_BIN \$DAEMON_ARGS

exit 0
EOF
chmod a+x /usr/bin/usbhaspd
cat << EOF > /lib/systemd/system/usbhaspd.service
[Unit]
Description=Usbhasp daemon

[Service]
Type=simple
ExecStart=/usr/bin/usbhaspd

[Install]
WantedBy=multi-user.target
EOF

if [[ $ARCH == "x86_64" ]]; then aksusbd_bin="aksusbd_x86_64"; else aksusbd_bin="aksusbd"; fi
cp -fp $SDIR/sbin/$aksusbd_bin /usr/sbin/
cat << EOF > /etc/udev/rules.d/80-hasp.rules
# HASP rules
ACTION=="add|change|bind", SUBSYSTEM=="usb", ATTRS{idVendor}=="0529", ATTRS{idProduct}=="0001", MODE="664", ENV{HASP}="1", SYMLINK+="aks/hasp/%k", RUN+="/usr/sbin/$aksusbd_bin -c \$root/aks/hasp/\$kernel"
ACTION=="remove", ENV{HASP}=="1", RUN+="/usr/sbin/$aksusbd_bin -r \$root/aks/hasp/\$kernel"

# SENTINEL rules
ACTION=="add|change|bind", SUBSYSTEM=="usb", ATTRS{idVendor}=="0529", ATTRS{idProduct}=="0003", KERNEL!="hiddev*", MODE="666", GROUP="plugdev", ENV{SENTINELHID}="1", SYMLINK+="aks/sentinelhid/%k"
EOF
cat << EOF > /etc/systemd/system/aksusbd.service
[Unit]
Description=Sentinel LDK Runtime Environment (aksusbd daemon)

[Service]
Type=forking
ExecStart=/usr/sbin/$aksusbd_bin

[Install]
WantedBy=multi-user.target
EOF
cp -fp $SDIR/sbin/hasplm /usr/sbin/
mkdir -p /etc/hasplm/
cat << EOF > /etc/hasplm/hasplm.conf
[NHS_SERVER]
NHS_USERLIST     = 250
;;NHS_SERVERNAMES  = LM1
NHS_HIGHPRIORITY = no

[NHS_IP]
NHS_USE_UDP      = Enabled
NHS_USE_TCP      = Disabled
NHS_IP_portnum   = 475
;;NHS_IP_LIMIT	   = 192.168.* 

[NHS_IPX]
NHS_USE_IPX      = Disabled

[NHS_NETBIOS]
NHS_USE_NETBIOS  = Disabled
EOF
cat << EOF > /etc/systemd/system/hasplm.service
[Unit]
Description=Sentinel LM

[Service]
Type=forking
ExecStart=/usr/sbin/hasplm -c /etc/hasplm/hasplm.conf

[Install]
WantedBy=multi-user.target
EOF
cd $SDIR/src/UsbHaspInfo/
if [[ $ARCH == "x86_64" ]]; then
  case $PM in
    apt-get) $PM install gcc-multilib -y;;
    dnf|yum) $PM install libgcc.i686 glibc-devel.i686 -y;;
  esac
  if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при установке пакетов"; exit 1; fi
  m32=" -m32"
else m32=""; fi
gcc$m32 -c *.c && gcc$m32 *.o libhasplnx.a -o usbhaspinfo
if [[ $? -ne 0 ]]; then >&2 echo "Ошибка при компиляции исходников 'usbhaspinfo'"; exit 1; fi
cp -fp $SDIR/src/UsbHaspInfo/usbhaspinfo /usr/sbin/
cat << EOF > /etc/hasplm/nethasp.ini
[NH_COMMON]
NH_TCPIP = Enabled

[NH_TCPIP]
NH_SERVER_ADDR = 127.0.0.1
NH_USE_BROADCAST = Disabled
EOF
systemctl daemon-reload
systemctl is-active --quiet aksusbd && systemctl stop aksusbd
systemctl is-active --quiet hasplm && systemctl stop hasplm
systemctl is-active --quiet usbhaspd && systemctl stop usbhaspd
systemctl start aksusbd && systemctl enable aksusbd
systemctl start hasplm && systemctl enable hasplm
systemctl start usbhaspd && systemctl enable usbhaspd
>&2 echo -e "\nЗавершено\n"
