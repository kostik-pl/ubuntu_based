#!/bin/bash

if [[ "$(id -u)" != "0" ]]; then echo "This script must be run as root"; exit 1; fi
ARCH=$(uname -m); if [[ $ARCH != "i686" ]] && [[ $ARCH != "x86_64" ]]; then >&2 echo "Данная архитектура не поддерживается"; exit 1; fi
PM=$(dpkg --version 1>/dev/null 2>&1 && echo dpkg) || PM=$(rpm --version 1>/dev/null 2>&1 && echo rpm)
if [[ $? -ne 0 ]]; then >&2 echo "Данный менеджер пакетов не поддерживается"; exit 1; fi

systemctl is-active --quiet aksusbd && systemctl stop aksusbd
systemctl is-active --quiet hasplm && systemctl stop hasplm
systemctl is-active --quiet usbhaspd && systemctl stop usbhaspd
systemctl is-enabled --quiet aksusbd && systemctl disable aksusbd
systemctl is-enabled --quiet hasplm && systemctl disable hasplm
systemctl is-enabled --quiet usbhaspd && systemctl disable usbhaspd
case $PM in
  dpkg) dpkg -s aksusbd 2>/dev/null 1>&2 && dpkg -P aksusbd;;
  rpm) rpm -q aksusbd 2>/dev/null 1>&2 && rpm -e aksusbd;;
esac
rm -f /usr/sbin/usbhaspinfo
rm -f /etc/hasplm/nethasp.ini
rm -f /etc/systemd/system/hasplm.service && systemctl daemon-reload
rm -f /usr/sbin/hasplm
rm -f /etc/hasplm/hasplm.conf
[[ $(ls /etc/hasplm/ | wc -l) -eq 0 ]] && rm -rf /etc/hasplm/
rm -f /etc/systemd/system/aksusbd.service
if [[ $ARCH == "x86_64" ]]; then aksusbd_bin="aksusbd_x86_64"; else aksusbd_bin="aksusbd"; fi
rm -f /usr/sbin/$aksusbd_bin
rm -f /etc/udev/rules.d/80-hasp.rules
case $PM in
  dpkg) dpkg -s usbhasp 2>/dev/null 1>&2 && dpkg -P usbhasp;;
  rpm) rpm -q usbhasp 2>/dev/null 1>&2 && rpm -e usbhasp;;
esac
rm -f /lib/systemd/system/usbhaspd.service
rm -f /usr/bin/usbhaspd
rm -f /etc/usbhaspd/usbhaspd.conf
[[ $(ls /etc/usbhaspd/keys/ | wc -l) -eq 0 ]] && rm -rf /etc/usbhaspd/keys/
[[ $(ls /etc/usbhaspd/ | wc -l) -eq 0 ]] && rm -rf /etc/usbhaspd/
rm -f /usr/bin/usbhasp
case $PM in
  dpkg) dpkg -s libusb-vhci 2>/dev/null 1>&2 && dpkg -P libusb-vhci;;
  rpm) rpm -q libusb-vhci 2>/dev/null 1>&2 && rpm -e libusb-vhci;;
esac
[[ -f /usr/lib/i386-linux-gnu/libusb_vhci.so.0 ]] && rm -f /usr/lib/i386-linux-gnu/libusb_vhci.so.0
[[ -f /usr/lib/i386-linux-gnu/libusb_vhci.so.0.0.0 ]] && rm -f /usr/lib/i386-linux-gnu/libusb_vhci.so.0.0.0
[[ -f /usr/lib/x86_64-linux-gnu/libusb_vhci.so.0 ]] && rm -f /usr/lib/x86_64-linux-gnu/libusb_vhci.so.0
[[ -f /usr/lib/x86_64-linux-gnu/libusb_vhci.so.0.0.0 ]] && rm -f /usr/lib/x86_64-linux-gnu/libusb_vhci.so.0.0.0
[[ -f /usr/local/lib/libusb_vhci.so.0 ]] && rm -f /usr/local/lib/libusb_vhci.so.0
[[ -f /usr/local/lib/libusb_vhci.so.0.0.0 ]] && rm -f /usr/local/lib/libusb_vhci.so.0.0.0
ldconfig
lsmod | tail -n +2 | sort | awk '{print $1;}' | grep ^usb_vhci_iocifc$ 1>/dev/null && modprobe -r usb_vhci_iocifc
lsmod | tail -n +2 | sort | awk '{print $1;}' | grep ^usb_vhci_hcd$ 1>/dev/null && modprobe -r usb_vhci_hcd
case $PM in
  dpkg) dpkg -s usb-vhci-hcd-dkms 2>/dev/null 1>&2 && dpkg -P usb-vhci-hcd-dkms;;
  rpm) rpm -q usb-vhci-hcd-dkms 2>/dev/null 1>&2 && rpm -e usb-vhci-hcd-dkms;;
esac
dkms status usb-vhci-hcd/1.15.1 | grep installed 1> /dev/null && dkms remove usb-vhci-hcd/1.15.1 --all
rm -f /usr/include/linux/usb-vhci.h
rm -rf /usr/src/usb-vhci-hcd-1.15.1/
